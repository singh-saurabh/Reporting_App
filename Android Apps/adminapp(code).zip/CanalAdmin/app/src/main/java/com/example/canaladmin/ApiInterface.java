package com.example.canaladmin;
import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.PATCH;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiInterface {

    @POST("/api/authenticate/")
    Call<LoginResponse> login(@Body LoginRequestBody credentials);

    @GET("/api/request/query/")
    Call<List<QueryItem>> QueryRequest(@Query("username") String username,@Query("password") String password,@Query("authority") String authority);

    @GET("/api/photo/{photoid}/")
    Call<mediaResponse> Photo(@Path("photoid") Integer photoid,@Query("username") String username,@Query("password") String password,@Query("authority") String authority);

    @GET("/api/query/")
    Call<QueryItem> QueryItemRequest(@Query("id") Integer id,@Query("username") String username,@Query("password") String password,@Query("authority") String authority);

    @POST("/api/request/changestate/")
    Call<QueryItem> update(@Body updateBody upbody);

    @POST("/api/request/changestate/")
    Call<QueryItem> updateAssign(@Body updateBodyAssign upbody);
}