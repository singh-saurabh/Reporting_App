package com.example.canaladmin;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AUP {

    @SerializedName("username")
    @Expose
    private String username;
    @SerializedName("password")
    @Expose
    private String password;
    @SerializedName("authority")
    @Expose
    private String authority;

    public String getUsername() {
        return username;
    }
    public AUP(String username, String password,String authority)
    {
        this.username=username;
        this.password=password;
        this.authority=authority;
    }
    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}

