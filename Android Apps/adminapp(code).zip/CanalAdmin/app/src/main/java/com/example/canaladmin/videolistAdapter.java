package com.example.canaladmin;

import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class videolistAdapter extends BaseAdapter {

    private Activity context;
    private List<Integer> list;
    private static LayoutInflater inflater=null;
    private int var=0;

    public videolistAdapter(Activity a, List<Integer> list) {
        context = a;
        this.list=list;
    }

    public int getCount() {
        return list.size();
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(final int position, final View convertView, final ViewGroup parent) {
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
       final View vi = inflater.inflate(R.layout.videolist, null);

        final TextView vid=(TextView) vi.findViewById(R.id.video);

        Retrofit retrofit=null;
        String sss="";
        ApiInterface api_service = getRetrofitInstance(context.getResources().getString(R.string.base_url), retrofit).create(ApiInterface.class);
        Call<mediaResponse> call = api_service.Photo(list.get(position),context.getSharedPreferences("canaladmin", 0).getString("username", "-1")
                        ,context.getSharedPreferences("canaladmin", 0).getString("password", "-1"),context.getSharedPreferences("canaladmin", 0).getString("authority", "-1")
                );
        final Intent i=new Intent (context,VideoPlayer.class);
//        final Intent i = new Intent(Intent.ACTION_VIEW);
        call.enqueue(new Callback<mediaResponse>() {
            @Override
            public void onResponse(Call<mediaResponse> call, Response<mediaResponse> response) {
                if(response.body()!=null) {
                    String s = response.body().getImage();
                    String url = context.getResources().getString(R.string.base_url);

                    int fl = 0;
                    for (int i = 3; i < s.length(); ++i) {
                        if (fl == 1)
                            url = url + s.charAt(i);
                        if (fl == 0 && s.charAt(i) == '0' && s.charAt(i - 1) == '0' && s.charAt(i - 2) == '0')
                            fl = 1;
                    }
                    vid.setText("Video "+(var+1));
                    i.setData(Uri.parse(url));
                    vi.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            context.startActivity(i);
                        }
                    });
                    vid.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            context.startActivity(i);
                        }
                    });
                }
            }
            @Override
            public void onFailure(Call<mediaResponse> call, Throwable t) {
            }
        });
        return vi;
    }
    public static Retrofit getRetrofitInstance(String base_url, Retrofit retrofit) {
        if (retrofit == null) {
            retrofit = new retrofit2.Retrofit.Builder()
                    .baseUrl(base_url)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }
}
