package com.example.canaladmin;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class updateBody {

    @SerializedName("status")
    @Expose
    private String status_code;
    @SerializedName("username")
    @Expose
    private String username;
    @SerializedName("password")
    @Expose
    private String password;
    @SerializedName("id")
    @Expose
    private Integer id;



    public updateBody(String status_code,String username,String password,Integer id)
    {
        this.status_code=status_code;
        this.username=username;
        this.id=id;
        this.password=password;
    }


}
