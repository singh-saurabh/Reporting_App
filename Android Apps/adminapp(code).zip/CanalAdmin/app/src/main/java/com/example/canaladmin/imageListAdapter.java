package com.example.canaladmin;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class imageListAdapter extends BaseAdapter {

        private Activity context;
        private List<Integer> list;
        private static LayoutInflater inflater=null;

        public imageListAdapter(Activity a, List<Integer> list) {
            context = a;
            this.list=list;
        }

        public int getCount() {
            return list.size();
        }

        public Object getItem(int position) {
            return position;
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            View vi = convertView;
            inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            if (convertView == null)
                vi = inflater.inflate(R.layout.imagelist, null);

           final ImageView image= (ImageView) vi.findViewById(R.id.image);

            Retrofit retrofit=null;
            ApiInterface api_service = getRetrofitInstance(context.getResources().getString(R.string.base_url), retrofit).create(ApiInterface.class);
            Call<mediaResponse> call = api_service.Photo(list.get(position),context.getSharedPreferences("canaladmin", 0).getString("username", "-1")
                            ,context.getSharedPreferences("canaladmin", 0).getString("password", "-1"),context.getSharedPreferences("canaladmin", 0).getString("authority", "-1")
                    );
            call.enqueue(new Callback<mediaResponse>() {
                @Override
                public void onResponse(Call<mediaResponse> call, Response<mediaResponse> response) {
                    if(response.body()!=null)
                    {
                        String s=response.body().getImage();
                        String url=context.getResources().getString(R.string.base_url);
                        int fl=0;
                        for(int i=3;i<s.length();++i)
                        {
                            if(fl==1)
                                url=url+s.charAt(i);
                            if(fl==0&&s.charAt(i)=='0'&&s.charAt(i-1)=='0'&&s.charAt(i-2)=='0')
                                fl=1;
                        }
                        Log.d("------------->",url);
                        final String ss=url;
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    URL urll = new URL(ss);
                                    final Bitmap bmp = BitmapFactory.decodeStream(urll.openConnection().getInputStream());
                                    context.runOnUiThread(new Runnable() {

                                        @Override
                                        public void run() {
                                            Log.d("-","0000000000000000000000");
                                            image.setImageBitmap(bmp);
                                        }
                                    });
                                }
                                catch (Exception e){

                                    Log.d("",e.toString());
                                }

                            }
                        }).start();
                    }
                }

                @Override
                public void onFailure(Call<mediaResponse> call, Throwable t) {
                }
            });

           return vi;
        }
    public static Retrofit getRetrofitInstance(String base_url, Retrofit retrofit) {
        if (retrofit == null) {
            retrofit = new retrofit2.Retrofit.Builder()
                    .baseUrl(base_url)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }
}
