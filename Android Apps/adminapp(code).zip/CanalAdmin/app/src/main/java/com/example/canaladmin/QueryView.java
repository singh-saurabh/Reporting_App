package com.example.canaladmin;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class QueryView extends AppCompatActivity {
    Retrofit retrofit;
    ListView imagelist;
    ListView videolist;
    imageListAdapter adapter;
    videolistAdapter vadapter;
    Integer id;
    WebView myWebView;
    String mapPath = "https://maps.google.com/maps?t=k&q=";
    ArrayList<Integer> l1,l2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String reviewer=getSharedPreferences("canaladmin", 0).getString("reviewer", "true");
        Log.d("--------------------",reviewer+"");
        l1=new ArrayList<Integer>();
        l2=new ArrayList<Integer>();
        setContentView(R.layout.query_view);
        final WebView browser = (WebView) findViewById(R.id.mapview);
        browser.getSettings().setBuiltInZoomControls(false);
        browser.getSettings().setDisplayZoomControls(false);
        browser.getSettings().setDomStorageEnabled(true);
        browser.getSettings().setJavaScriptEnabled(true);
        browser.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return false;
            }
        });

        Intent i=getIntent();
        id=i.getIntExtra("id",-1);
        String listch=i.getStringExtra("list");
        if(listch.equals("resolved"))
        {
            findViewById(R.id.buttons).setVisibility(View.GONE);
        }
        if(listch.equals("assigned"))
        {
            if(reviewer.equals("true"))
            {
                findViewById(R.id.buttons).setVisibility(View.GONE);
            }
            findViewById(R.id.engineers).setVisibility(View.GONE);
            findViewById(R.id.duplicated).setVisibility(View.GONE);
            findViewById(R.id.spam).setVisibility(View.GONE);
            findViewById(R.id.assign).setVisibility(View.GONE);
        }
        if(listch.equals("pending"))
        {
            findViewById(R.id.assigned_to).setVisibility(View.INVISIBLE);
            findViewById(R.id.ressolve).setVisibility(View.GONE);
            if(reviewer.equals("true"))
            findViewById(R.id.engineers).setVisibility(View.GONE);
            if(reviewer.equals("true"))
            findViewById(R.id.assign).setVisibility(View.GONE);
        }

        findViewById(R.id.ressolve).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(QueryView.this)
                        .setTitle("Title")
                        .setMessage("Do you really want to resolve?")
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton("YES", new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int whichButton) {
                                Intent data = new Intent();
                                String text = "Result to be returned....";
                                data.setData(Uri.parse(text));
                                setResult(5, data);
                                update("Resolved");

                            }})
                        .setNegativeButton("NO", null).show();
            }
        });
        findViewById(R.id.duplicated).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(QueryView.this)
                        .setTitle("Title")
                        .setMessage("Do you really want to mark this query as duplicate?")
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton("YES", new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int whichButton) {
                                Intent data = new Intent();
                                String text = "Result to be returned....";
                                data.setData(Uri.parse(text));
                                setResult(5, data);
                                update("Duplicate");
                            }})
                        .setNegativeButton("NO", null).show();
            }
        });findViewById(R.id.spam).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(QueryView.this)
                        .setTitle("Title")
                        .setMessage("Do you really want to mark this query as spam?")
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton("YES", new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int whichButton) {
                                Intent data = new Intent();
                                String text = "Result to be returned....";
                                data.setData(Uri.parse(text));
                                setResult(5, data);
                                update("Spam");
                            }})
                        .setNegativeButton("NO", null).show();

            }
        });
        findViewById(R.id.assign).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(QueryView.this)
                        .setTitle("Title")
                        .setMessage("Do you really want to assign this?")
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton("YES", new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int whichButton) {
                                Intent data = new Intent();
                                String text = "Result to be returned....";
                                data.setData(Uri.parse(text));
                                setResult(5, data);

                                updateass("Assigned",((Spinner)findViewById(R.id.engineers)).getSelectedItem().toString());
                            }})
                        .setNegativeButton("NO", null).show();
            }
        });

        imagelist=findViewById(R.id.image_list);
        videolist=findViewById(R.id.video_list);
        Log.d("->>>>>>>>>>>>>>",">>>>>>");
        ApiInterface api_service = getRetrofitInstance(getResources().getString(R.string.base_url), retrofit).create(ApiInterface.class);

        Call<QueryItem> call = api_service.QueryItemRequest(id,getSharedPreferences("canaladmin", 0).getString("username", "-1")
                        ,getSharedPreferences("canaladmin", 0).getString("password", "-1"),getSharedPreferences("canaladmin", 0).getString("authority", "-1"))
                ;
        call.enqueue(new Callback<QueryItem>() {
            @Override
            public void onResponse(Call<QueryItem> call, final Response<QueryItem> response) {


                ((TextView)findViewById(R.id.query_text)).setText(response.body().getText());
                Log.d("--------",response.body().getText());
                ((TextView)findViewById(R.id.id)).setText("QUERY : "+(response.body().getId()+1));
                ((TextView)findViewById(R.id.assigned_to)).setText(response.body().getAssigned());
                adapter=new imageListAdapter(QueryView.this,l1);
                imagelist.setAdapter(adapter);
//                mapPath = "https://maps.google.com/maps?q=37.0625,-95.677068"+response.body().getLatitude()+","+response.body().getLongitude();
//                browser.loadUrl(mapPath);
                vadapter=new videolistAdapter(QueryView.this,l2);
                videolist.setAdapter(vadapter);
                ApiInterface api_service = getRetrofitInstance(getApplicationContext().getResources().getString(R.string.base_url), retrofit).create(ApiInterface.class);
                for(int i=0;i<response.body().getMedia().size();++i) {
                    final int j=i;
                    Call<mediaResponse> call1 = api_service.Photo(response.body().getMedia().get(i),getSharedPreferences("canaladmin", 0).getString("username", "-1")
                                    ,getSharedPreferences("canaladmin", 0).getString("password", "-1"),getSharedPreferences("canaladmin", 0).getString("authority", "-1")
                            );
                    call1.enqueue(new Callback<mediaResponse>() {
                        @Override
                        public void onResponse(Call<mediaResponse> call, Response<mediaResponse> response1) {
                            if (response1.body() != null) {
                                String s = response1.body().getImage();
                                 if(s.charAt(s.length()-1)=='g'||s.charAt(s.length()-1)=='G')
                                 {

                                     l1.add(response.body().getMedia().get(j));
                                     adapter.notifyDataSetChanged();
                                 }
                                 else
                                 {
                                     l2.add(response.body().getMedia().get(j));
                                     vadapter.notifyDataSetChanged();
                                 }
                            }
                        }

                        @Override
                        public void onFailure(Call<mediaResponse> call, Throwable t) {
                        }
                    });
                }
            }

            @Override
            public void onFailure(Call<QueryItem> call, Throwable t) {
                Log.d(">>>>>>>>>",">>>>>>>"+t.getMessage());
                findViewById(R.id.noQuery).setVisibility(View.INVISIBLE);
            }
        });


    }

    void update(String s)
    {
        ApiInterface api_service = getRetrofitInstance(getResources().getString(R.string.base_url), retrofit).create(ApiInterface.class);

        Call<QueryItem> call = api_service.update(new updateBody(s,getSharedPreferences("canaladmin", 0).getString("username", "-1")
                ,getSharedPreferences("canaladmin", 0).getString("password", "-1")
                ,id
                ));
        call.enqueue(new Callback<QueryItem>() {
            @Override
            public void onResponse(Call<QueryItem> call, final Response<QueryItem> response) {
                finish();
            }

            @Override
            public void onFailure(Call<QueryItem> call, Throwable t) {
                finish();
            }
        });
    }

    void updateass(String s,String s2)
    {
        ApiInterface api_service = getRetrofitInstance(getResources().getString(R.string.base_url), retrofit).create(ApiInterface.class);

        Call<QueryItem> call = api_service.updateAssign(new updateBodyAssign(
                s,
                getSharedPreferences("canaladmin", 0).getString("username", "-1"),
                getSharedPreferences("canaladmin", 0).getString("password", "-1"),
                id,
                s2
        ));
        call.enqueue(new Callback<QueryItem>() {
            @Override
            public void onResponse(Call<QueryItem> call, final Response<QueryItem> response) {
                finish();
            }

            @Override
            public void onFailure(Call<QueryItem> call, Throwable t) {
                finish();
            }
        });
    }


    public static Retrofit getRetrofitInstance(String base_url,Retrofit retrofit) {
        if (retrofit == null) {
            retrofit = new retrofit2.Retrofit.Builder()
                    .baseUrl(base_url)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }
}